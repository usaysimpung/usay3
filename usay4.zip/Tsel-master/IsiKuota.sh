#!/system/xbin/bash
#Bersihkan Layar
clear
blue='\e[1;34m'
green='\e[1;32m'
purple='\[1;35m'
cyan='\e[1;36m'
red='\e[1;31m'
white='\e[1;37m'
yellow='\e[1;33m'
sleep 1
echo "\033[32;1m=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*"
toilet -f standard -F gay "Tembak Kuota"
echo "\033[31;1m=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*"
echo ""
echo "Author : " Mr.TamfanX"
" Team : " MRTAMFANX CYBER TEAM"
echo " Kontak Me : " 085779515200"
" Pesan : "Jangan Di Salah Gunakan Dan Disebar :) Karena Nanti Dosa Tanggung Sendiri:)"
sleep 1
echo "ThanksTo:"
echo "Allmember MRTAMFANX CYBER TEAM"
echo "\033[33;1m=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*"
echo ""
sleep 2
echo "Mau Tembak Kuota...""Silahkan Pilih No Dibawah Bacaan Ini !"
sleep 3
echo "1.XL/AXIS"
sleep 3
echo "2.INDOSAT"
sleep 2
echo "3.SIMPATI"
sleep 3
echo "4.SMARTFREN"
sleep 2
echo "5.3(Three)"
sleep 3
echo "masukkan kodenya"
read p;
echo "\033[31;1mSedang Menuju Proses..."
sleep 3
echo "\033[37;1m█10%"
sleep 2
echo "██20%"
sleep 5
echo "███30%"
sleep 3
echo "████40%"
sleep 3
echo "█████50%"
sleep 3
echo "██████60%"
sleep 3
echo "███████70%"
sleep 4
echo "████████80%"
sleep 3
echo "█████████90%"
sleep 4
echo "██████████100%"
sleep 3
clear

echo "\033[33;1mMasukkan Nomer Anda Yang Benar...Contoh:0857xxxx"
sleep 2
echo "Isi Dibawah!"
read p;
clear

echo "\033[33;1mSilahkan Pilih Dari Daftar Menu Dibawah Ini!"
sleep 2
echo "\033[35;1m1.Paket UNLIMITED INDOSAT"
sleep 2
echo "2.Paket UNLIMITED SMARTFREN"
sleep 2
echo "3.Paket UNLIMITED AXIS/XL"
sleep 2
echo "4.Paket UNLIMITED SIMPATI/TELKOMSEL"
sleep 2
echo "5.Paket UNLIMITED 3(Three)"
sleep 2
echo "masukkan Kodenya..."
read p;
clear

echo "\033[33;1mTunggulah Sekitar 10 Menit Untuk Mendapatkan Sms Masuk...."
sleep 1
echo "Jika 10Menit Belum Ada Sms Masuk Berarti No Kamu tidak Valid...!!"
sleep 2
echo "Thanks To:MrUncle - MrTamfanX - Owl Cyber Team"
sleep 2
echo "Pesan:Jangan Salahin Admin Ya Kentod...Mau Kuota Gratis Ga Sabar..."
sleep 3


